"""SQLite persistence for Phase 1 background crawls and rank snapshots."""

from __future__ import annotations

import json
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Storage:
    """Small synchronous SQLite repository.

    A connection is opened per operation. WAL mode plus a process lock keeps writes
    deterministic while background asyncio tasks report progress concurrently.
    """

    JOB_FIELDS = {
        "status",
        "stage",
        "progress_percent",
        "pages_scanned",
        "available_results",
        "discovered_count",
        "processed_count",
        "success_count",
        "failed_count",
        "discovery_source",
        "warnings_json",
        "error",
        "cancel_requested",
        "started_at",
        "finished_at",
        "json_path",
        "csv_path",
    }

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.init_schema()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 30000")
        return connection

    def init_schema(self) -> None:
        schema = """
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;

        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            niche TEXT NOT NULL,
            requested_limit INTEGER NOT NULL,
            status TEXT NOT NULL DEFAULT 'queued',
            stage TEXT NOT NULL DEFAULT 'queued',
            progress_percent REAL NOT NULL DEFAULT 0,
            pages_scanned INTEGER NOT NULL DEFAULT 0,
            available_results INTEGER,
            discovered_count INTEGER NOT NULL DEFAULT 0,
            processed_count INTEGER NOT NULL DEFAULT 0,
            success_count INTEGER NOT NULL DEFAULT 0,
            failed_count INTEGER NOT NULL DEFAULT 0,
            discovery_source TEXT,
            warnings_json TEXT NOT NULL DEFAULT '[]',
            error TEXT,
            cancel_requested INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            started_at TEXT,
            updated_at TEXT NOT NULL,
            finished_at TEXT,
            json_path TEXT,
            csv_path TEXT
        );

        CREATE TABLE IF NOT EXISTS search_results (
            job_id TEXT NOT NULL,
            url TEXT NOT NULL,
            niche TEXT NOT NULL,
            page_number INTEGER,
            page_position INTEGER,
            global_position INTEGER,
            organic_position INTEGER,
            sponsored_position INTEGER,
            is_sponsored INTEGER NOT NULL DEFAULT 0,
            seller_online INTEGER NOT NULL DEFAULT 0,
            card_title TEXT,
            card_seller_name TEXT,
            card_seller_username TEXT,
            card_seller_level TEXT,
            card_rating REAL,
            card_review_count INTEGER,
            card_price REAL,
            currency TEXT,
            thumbnail_url TEXT,
            badges_json TEXT NOT NULL DEFAULT '[]',
            raw_card_text TEXT,
            discovered_at TEXT NOT NULL,
            PRIMARY KEY (job_id, url),
            FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_search_job_rank
            ON search_results(job_id, global_position);
        CREATE INDEX IF NOT EXISTS idx_search_url
            ON search_results(url);

        CREATE TABLE IF NOT EXISTS gig_snapshots (
            job_id TEXT NOT NULL,
            url TEXT NOT NULL,
            status TEXT NOT NULL,
            fetched_at TEXT NOT NULL,
            fetch_method TEXT,
            title TEXT,
            seller_username TEXT,
            seller_name TEXT,
            seller_level TEXT,
            rating REAL,
            review_count INTEGER,
            starting_price_usd REAL,
            error TEXT,
            result_json TEXT NOT NULL,
            PRIMARY KEY (job_id, url),
            FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_snapshots_job
            ON gig_snapshots(job_id);

        CREATE TABLE IF NOT EXISTS gigs (
            url TEXT PRIMARY KEY,
            title TEXT,
            seller_username TEXT,
            seller_name TEXT,
            first_seen_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            latest_result_json TEXT NOT NULL
        );
        """
        with self._lock, self._connect() as connection:
            connection.executescript(schema)

    def recover_incomplete_jobs(self) -> int:
        """Mark jobs left running by a previous process as interrupted."""
        now = utc_now()
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE jobs
                SET status='interrupted', stage='interrupted',
                    error=COALESCE(error, 'Server restarted before this job completed.'),
                    finished_at=?, updated_at=?
                WHERE status IN ('queued', 'running', 'cancelling')
                """,
                (now, now),
            )
            return cursor.rowcount

    def create_job(self, job_id: str, niche: str, requested_limit: int) -> dict[str, Any]:
        now = utc_now()
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO jobs (
                    id, niche, requested_limit, status, stage,
                    created_at, updated_at
                ) VALUES (?, ?, ?, 'queued', 'queued', ?, ?)
                """,
                (job_id, niche, requested_limit, now, now),
            )
        job = self.get_job(job_id)
        if job is None:  # pragma: no cover - defensive
            raise RuntimeError("Created job could not be reloaded")
        return job

    def update_job(self, job_id: str, **fields: Any) -> None:
        clean: dict[str, Any] = {}
        for key, value in fields.items():
            if key not in self.JOB_FIELDS:
                raise ValueError(f"Unsupported job field: {key}")
            if key == "warnings_json" and not isinstance(value, str):
                value = json.dumps(value, ensure_ascii=False)
            if key == "cancel_requested":
                value = int(bool(value))
            clean[key] = value
        if not clean:
            return
        clean["updated_at"] = utc_now()
        assignments = ", ".join(f"{key}=?" for key in clean)
        values = list(clean.values()) + [job_id]
        with self._lock, self._connect() as connection:
            connection.execute(
                f"UPDATE jobs SET {assignments} WHERE id=?",  # fields are allow-listed
                values,
            )

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._lock, self._connect() as connection:
            row = connection.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        return self._job_row(row) if row else None

    def list_jobs(self, limit: int = 20) -> list[dict[str, Any]]:
        limit = max(1, min(100, int(limit)))
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [self._job_row(row) for row in rows]

    @staticmethod
    def _job_row(row: sqlite3.Row) -> dict[str, Any]:
        data = dict(row)
        try:
            data["warnings"] = json.loads(data.pop("warnings_json") or "[]")
        except json.JSONDecodeError:
            data["warnings"] = []
            data.pop("warnings_json", None)
        data["cancel_requested"] = bool(data.get("cancel_requested"))
        return data

    def request_cancel(self, job_id: str) -> bool:
        now = utc_now()
        with self._lock, self._connect() as connection:
            cursor = connection.execute(
                """
                UPDATE jobs
                SET cancel_requested=1,
                    status=CASE WHEN status IN ('queued','running') THEN 'cancelling' ELSE status END,
                    stage=CASE WHEN status IN ('queued','running') THEN 'cancelling' ELSE stage END,
                    updated_at=?
                WHERE id=? AND status IN ('queued','running','cancelling')
                """,
                (now, job_id),
            )
            return cursor.rowcount > 0

    def is_cancel_requested(self, job_id: str) -> bool:
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT cancel_requested FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
        return bool(row and row[0])

    def save_search_results(self, job_id: str, records: Iterable[dict[str, Any]]) -> int:
        rows = list(records)
        if not rows:
            return 0
        now = utc_now()
        sql = """
        INSERT INTO search_results (
            job_id, url, niche, page_number, page_position, global_position,
            organic_position, sponsored_position, is_sponsored, seller_online,
            card_title, card_seller_name, card_seller_username, card_seller_level,
            card_rating, card_review_count, card_price, currency, thumbnail_url,
            badges_json, raw_card_text, discovered_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(job_id, url) DO UPDATE SET
            page_number=excluded.page_number,
            page_position=excluded.page_position,
            global_position=excluded.global_position,
            organic_position=excluded.organic_position,
            sponsored_position=excluded.sponsored_position,
            is_sponsored=excluded.is_sponsored,
            seller_online=excluded.seller_online,
            card_title=COALESCE(excluded.card_title, search_results.card_title),
            card_seller_name=COALESCE(excluded.card_seller_name, search_results.card_seller_name),
            card_seller_level=COALESCE(excluded.card_seller_level, search_results.card_seller_level),
            card_rating=COALESCE(excluded.card_rating, search_results.card_rating),
            card_review_count=COALESCE(excluded.card_review_count, search_results.card_review_count),
            card_price=COALESCE(excluded.card_price, search_results.card_price),
            thumbnail_url=COALESCE(excluded.thumbnail_url, search_results.thumbnail_url),
            badges_json=excluded.badges_json,
            raw_card_text=excluded.raw_card_text
        """
        values = []
        for record in rows:
            values.append(
                (
                    job_id,
                    record["url"],
                    record.get("niche", ""),
                    record.get("page_number"),
                    record.get("page_position"),
                    record.get("global_position"),
                    record.get("organic_position"),
                    record.get("sponsored_position"),
                    int(bool(record.get("is_sponsored"))),
                    int(bool(record.get("seller_online"))),
                    record.get("card_title"),
                    record.get("card_seller_name"),
                    record.get("card_seller_username"),
                    record.get("card_seller_level"),
                    record.get("card_rating"),
                    record.get("card_review_count"),
                    record.get("card_price"),
                    record.get("currency"),
                    record.get("thumbnail_url"),
                    json.dumps(record.get("badges") or [], ensure_ascii=False),
                    record.get("raw_card_text"),
                    record.get("discovered_at") or now,
                )
            )
        with self._lock, self._connect() as connection:
            connection.executemany(sql, values)
        return len(values)

    def save_gig_result(self, job_id: str, result: dict[str, Any]) -> None:
        now = utc_now()
        status = "failed" if result.get("error") else "success"
        result_json = json.dumps(result, ensure_ascii=False)
        url = str(result["url"])
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO gig_snapshots (
                    job_id, url, status, fetched_at, fetch_method, title,
                    seller_username, seller_name, seller_level, rating,
                    review_count, starting_price_usd, error, result_json
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(job_id, url) DO UPDATE SET
                    status=excluded.status,
                    fetched_at=excluded.fetched_at,
                    fetch_method=excluded.fetch_method,
                    title=excluded.title,
                    seller_username=excluded.seller_username,
                    seller_name=excluded.seller_name,
                    seller_level=excluded.seller_level,
                    rating=excluded.rating,
                    review_count=excluded.review_count,
                    starting_price_usd=excluded.starting_price_usd,
                    error=excluded.error,
                    result_json=excluded.result_json
                """,
                (
                    job_id,
                    url,
                    status,
                    result.get("fetched_at") or now,
                    result.get("fetch_method"),
                    result.get("title"),
                    result.get("seller_username"),
                    result.get("seller_name"),
                    result.get("seller_level"),
                    result.get("rating"),
                    result.get("review_count"),
                    result.get("starting_price_usd"),
                    result.get("error"),
                    result_json,
                ),
            )
            connection.execute(
                """
                INSERT INTO gigs (
                    url, title, seller_username, seller_name,
                    first_seen_at, last_seen_at, latest_result_json
                ) VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(url) DO UPDATE SET
                    title=COALESCE(excluded.title, gigs.title),
                    seller_username=COALESCE(excluded.seller_username, gigs.seller_username),
                    seller_name=COALESCE(excluded.seller_name, gigs.seller_name),
                    last_seen_at=excluded.last_seen_at,
                    latest_result_json=excluded.latest_result_json
                """,
                (
                    url,
                    result.get("title"),
                    result.get("seller_username"),
                    result.get("seller_name"),
                    now,
                    now,
                    result_json,
                ),
            )

    def get_job_results(
        self, job_id: str, offset: int = 0, limit: int = 20
    ) -> tuple[list[dict[str, Any]], int]:
        offset = max(0, int(offset))
        limit = max(1, min(200, int(limit)))
        with self._lock, self._connect() as connection:
            total = connection.execute(
                "SELECT COUNT(*) FROM gig_snapshots WHERE job_id=?", (job_id,)
            ).fetchone()[0]
            rows = connection.execute(
                """
                SELECT gs.result_json
                FROM gig_snapshots gs
                LEFT JOIN search_results sr
                  ON sr.job_id=gs.job_id AND sr.url=gs.url
                WHERE gs.job_id=?
                ORDER BY COALESCE(sr.global_position, 999999), gs.url
                LIMIT ? OFFSET ?
                """,
                (job_id, limit, offset),
            ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            try:
                results.append(json.loads(row["result_json"]))
            except json.JSONDecodeError:
                continue
        return results, int(total)

    def get_all_job_results(self, job_id: str) -> list[dict[str, Any]]:
        results: list[dict[str, Any]] = []
        offset = 0
        while True:
            batch, total = self.get_job_results(job_id, offset=offset, limit=200)
            results.extend(batch)
            offset += len(batch)
            if not batch or offset >= total:
                break
        return results

    def get_all_search_results(self, job_id: str) -> list[dict[str, Any]]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                """
                SELECT * FROM search_results
                WHERE job_id=?
                ORDER BY COALESCE(global_position, 999999), url
                """,
                (job_id,),
            ).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            item["is_sponsored"] = bool(item.get("is_sponsored"))
            item["seller_online"] = bool(item.get("seller_online"))
            try:
                item["badges"] = json.loads(item.pop("badges_json") or "[]")
            except json.JSONDecodeError:
                item["badges"] = []
                item.pop("badges_json", None)
            results.append(item)
        return results

    def count_search_results(self, job_id: str) -> int:
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT COUNT(*) FROM search_results WHERE job_id=?", (job_id,)
            ).fetchone()
        return int(row[0]) if row else 0
