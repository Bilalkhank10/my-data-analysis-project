from __future__ import annotations

import re
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel, Field, field_validator

from job_manager import JobManager
from storage import Storage

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = DATA_DIR / "exports"
DATA_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

storage = Storage(DATA_DIR / "fiverr_phase1.db")
manager = JobManager(storage, OUTPUT_DIR)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    await manager.shutdown()


app = FastAPI(
    title="Fiverr Market Crawler — Phase 1",
    version="2.0.0",
    description="Background Fiverr public-market crawler with rank snapshots and SQLite.",
    lifespan=lifespan,
)


class FetchRequest(BaseModel):
    niche: str = Field(min_length=2, max_length=100)
    limit: int = Field(default=5, ge=1, le=500)

    @field_validator("niche")
    @classmethod
    def clean_niche(cls, value: str) -> str:
        value = " ".join(value.split()).strip()
        if len(value) < 2:
            raise ValueError("Niche kam az kam 2 characters ka hona chahiye.")
        return value


@app.get("/", response_class=HTMLResponse)
async def home() -> str:
    return INDEX_HTML


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "phase": 1,
        "database": str(storage.path.name),
    }


@app.post("/api/jobs", status_code=202)
async def create_job(request: FetchRequest) -> dict[str, Any]:
    return manager.start_job(request.niche, request.limit)


# Backwards-compatible route. It now starts a background job instead of holding
# one HTTP connection open for a potentially long 500-gig crawl.
@app.post("/api/fetch", status_code=202)
async def fetch_niche(request: FetchRequest) -> dict[str, Any]:
    return manager.start_job(request.niche, request.limit)


@app.get("/api/jobs")
async def list_jobs(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
    jobs = manager.list_jobs(limit)
    return {"jobs": jobs, "count": len(jobs)}


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/api/jobs/{job_id}/results")
async def get_job_results(
    job_id: str,
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    results, total = storage.get_job_results(job_id, offset=offset, limit=limit)
    return {
        "job_id": job_id,
        "status": job["status"],
        "offset": offset,
        "limit": limit,
        "total": total,
        "has_more": offset + len(results) < total,
        "results": results,
    }


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str) -> dict[str, Any]:
    job = manager.cancel_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/download/{filename}")
async def download(filename: str) -> FileResponse:
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.(json|csv)", filename):
        raise HTTPException(status_code=400, detail="Invalid filename")
    path = OUTPUT_DIR / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Export not found")
    media_type = "application/json" if path.suffix == ".json" else "text/csv"
    return FileResponse(path, filename=filename, media_type=media_type)


INDEX_HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Fiverr Market Crawler — Phase 1</title>
  <style>
    :root{--bg:#07120e;--panel:#0f2018;--panel2:#14281f;--line:#29483a;--text:#f3fbf6;--muted:#a5bdb1;--green:#1dbf73;--green2:#75ecb2;--danger:#ff7979;--warn:#ffd37a;--blue:#7cb7ff}
    *{box-sizing:border-box} body{margin:0;min-height:100vh;color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:radial-gradient(circle at 12% 4%,rgba(29,191,115,.16),transparent 30rem),radial-gradient(circle at 92% 24%,rgba(124,183,255,.08),transparent 25rem),var(--bg)}
    .wrap{width:min(1180px,calc(100% - 32px));margin:auto;padding:50px 0 80px}.eyebrow{color:var(--green2);font-size:12px;font-weight:900;letter-spacing:.15em;text-transform:uppercase}h1{margin:9px 0 12px;max-width:900px;font-size:clamp(36px,6vw,68px);line-height:1;letter-spacing:-.05em}.lead{max-width:780px;color:var(--muted);font-size:18px;line-height:1.6}
    .search-card{margin-top:30px;padding:20px;display:grid;grid-template-columns:1fr 150px auto;gap:12px;border:1px solid var(--line);background:rgba(15,32,24,.9);border-radius:18px;box-shadow:0 22px 65px rgba(0,0,0,.3)}label{display:block;margin:0 0 8px 2px;color:var(--muted);font-size:12px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}input,select,button,a.button{font:inherit}input,select{width:100%;height:50px;padding:0 15px;color:var(--text);background:#081710;border:1px solid var(--line);border-radius:12px;outline:none}input:focus,select:focus{border-color:var(--green);box-shadow:0 0 0 3px rgba(29,191,115,.12)}
    button,a.button{height:50px;align-self:end;display:inline-flex;align-items:center;justify-content:center;padding:0 21px;border:0;border-radius:12px;color:#03130a;background:var(--green);font-weight:900;text-decoration:none;cursor:pointer}button:hover,a.button:hover{background:var(--green2)}button:disabled{opacity:.55;cursor:not-allowed}.secondary{color:var(--text)!important;background:var(--panel2)!important;border:1px solid var(--line)!important}.danger{color:#fff!important;background:#672c32!important;border:1px solid #a94952!important}.fine{margin:12px 3px 0;color:#7f9a8d;font-size:13px;line-height:1.55}
    .job-panel{display:none;margin-top:24px;padding:20px;border:1px solid var(--line);border-radius:17px;background:var(--panel)}.job-panel.show{display:block}.job-top{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}.job-top h2{margin:0 0 5px;font-size:21px}.job-id{color:#7f9a8d;font:12px ui-monospace,monospace;overflow-wrap:anywhere}.stage{display:inline-flex;margin-top:8px;padding:5px 9px;border-radius:999px;color:var(--green2);background:#092017;border:1px solid #295440;font-size:12px;font-weight:800;text-transform:capitalize}.progress-track{height:12px;margin:18px 0 10px;overflow:hidden;border:1px solid #2b4b3d;border-radius:999px;background:#07120e}.progress-bar{height:100%;width:0;background:linear-gradient(90deg,var(--green),var(--green2));transition:width .35s ease}.metrics{display:grid;grid-template-columns:repeat(6,1fr);gap:9px}.metric{padding:11px;background:#091710;border:1px solid #233d32;border-radius:11px}.metric small{display:block;color:#82998e;font-size:11px;text-transform:uppercase}.metric strong{display:block;margin-top:3px;font-size:18px}.job-message{margin:12px 0 0;color:var(--muted);font-size:13px}.warning{margin:10px 0;padding:11px 13px;border:1px solid rgba(255,211,122,.35);border-radius:10px;color:var(--warn);background:rgba(255,211,122,.06);font-size:13px}.error{color:var(--danger)!important}
    .summary{display:none;margin:28px 0 15px;align-items:center;justify-content:space-between;gap:14px}.summary.show{display:flex}.summary h2{margin:0;font-size:25px}.summary p{margin:4px 0 0;color:var(--muted)}.downloads,.pager{display:flex;gap:8px;flex-wrap:wrap}.downloads a.button,.pager button{height:39px;padding:0 14px;color:var(--text);background:var(--panel2);border:1px solid var(--line);font-size:13px}.pager-wrap{display:none;margin:12px 0 18px;align-items:center;justify-content:space-between;gap:12px;color:var(--muted);font-size:13px}.pager-wrap.show{display:flex}
    .results{display:grid;gap:14px}.gig{overflow:hidden;border:1px solid var(--line);border-radius:17px;background:rgba(15,32,24,.92)}.gig-main{padding:19px;display:grid;grid-template-columns:1fr auto;gap:18px}.gig h3{margin:0 0 9px;font-size:19px;line-height:1.35}.gig h3 a{color:var(--text);text-decoration:none}.gig h3 a:hover{color:var(--green2)}.meta{display:flex;gap:7px;flex-wrap:wrap}.chip{padding:6px 9px;color:var(--muted);background:#081710;border:1px solid var(--line);border-radius:999px;font-size:12px}.chip.rank{color:#05140c;background:var(--green2);border-color:var(--green2);font-weight:900}.chip.ad{color:#1b1100;background:var(--warn);border-color:var(--warn);font-weight:900}.price{min-width:110px;text-align:right}.price small{display:block;color:var(--muted)}.price strong{font-size:24px;color:var(--green2)}details{border-top:1px solid var(--line)}summary{padding:14px 20px;color:var(--muted);font-weight:750;cursor:pointer}.detail-body{padding:4px 20px 20px;display:grid;gap:12px}.data-box{overflow:hidden;border:1px solid #28483a;border-radius:13px;background:#08130e}.data-head{min-height:45px;padding:8px 10px 8px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #1e352b;background:#102119}.data-head h4{margin:0;color:var(--green2);font-size:14px}button.copy-btn{width:auto;min-width:72px;height:30px;align-self:auto;padding:0 10px;color:var(--text);background:#183025;border:1px solid #365c4b;border-radius:8px;font-size:12px}button.copy-btn:hover,button.copy-btn.copied{color:#03130a;background:var(--green2)}pre{margin:0;max-height:360px;overflow:auto;padding:14px;white-space:pre-wrap;overflow-wrap:anywhere;color:#d9e9e0;background:#08130e;font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}
    footer{margin-top:42px;color:#6e887b;font-size:13px;line-height:1.6}@media(max-width:800px){.search-card{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,1fr)}.job-top,.summary,.gig-main,.pager-wrap{align-items:flex-start;flex-direction:column;display:flex}.summary,.pager-wrap{display:none}.summary.show,.pager-wrap.show{display:flex}.price{text-align:left}}
  </style>
</head>
<body><main class="wrap">
  <div class="eyebrow">Phase 1 · Persistent market-data foundation</div>
  <h1>Fiverr Market Crawler</h1>
  <p class="lead">Public Fiverr search ko background mein crawl karein, organic/sponsored rank positions capture karein, detail pages parse karein aur SQLite snapshots ke saath JSON/CSV export hasil karein.</p>
  <form id="form" class="search-card">
    <div><label for="niche">Niche / keyword</label><input id="niche" value="Looker Studio" minlength="2" maxlength="100" required></div>
    <div><label for="limit">Maximum gigs</label><select id="limit"><option>3</option><option selected>5</option><option>10</option><option>25</option><option>50</option><option>100</option><option>250</option><option>500</option></select></div>
    <button id="submit" type="submit">Start background job</button>
  </form>
  <p class="fine">500 gigs background job mein run hoti hain, is liye page request timeout nahi hota. Public URLs only; low concurrency, retries, deduplication aur rate limiting enabled hain.</p>

  <section id="jobPanel" class="job-panel">
    <div class="job-top"><div><h2 id="jobTitle">Crawl job</h2><div id="jobId" class="job-id"></div><span id="stage" class="stage">queued</span></div><button id="cancel" class="danger" type="button">Cancel job</button></div>
    <div class="progress-track"><div id="progressBar" class="progress-bar"></div></div>
    <div class="metrics">
      <div class="metric"><small>Progress</small><strong id="mProgress">0%</strong></div>
      <div class="metric"><small>Pages</small><strong id="mPages">0</strong></div>
      <div class="metric"><small>Discovered</small><strong id="mDiscovered">0</strong></div>
      <div class="metric"><small>Processed</small><strong id="mProcessed">0</strong></div>
      <div class="metric"><small>Success</small><strong id="mSuccess">0</strong></div>
      <div class="metric"><small>Failed</small><strong id="mFailed">0</strong></div>
    </div>
    <p id="jobMessage" class="job-message"></p><div id="warnings"></div>
  </section>

  <section id="summary" class="summary"><div><h2 id="summaryTitle">Results</h2><p id="summaryMeta"></p></div><div id="downloads" class="downloads"></div></section>
  <div id="pagerWrap" class="pager-wrap"><span id="pagerInfo"></span><div class="pager"><button id="prev" class="secondary" type="button">Previous</button><button id="next" class="secondary" type="button">Next</button></div></div>
  <section id="results" class="results"></section>
  <footer>Phase 1 stores public rank snapshots and gig details in SQLite. Search output is personalized/dynamic, so recorded rank is a controlled observation—not Fiverr’s universal leaderboard. No login, CAPTCHA, private analytics or access-control bypass is used.</footer>
</main>
<script>
const $=id=>document.getElementById(id); const PAGE_SIZE=20;
let currentJobId=null,pollTimer=null,currentOffset=0,currentTotal=0;
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined&&text!==null)n.textContent=text;return n}
function chip(text,extra=''){return el('span','chip '+extra,text)}
async function api(url,options={}){const r=await fetch(url,options);const d=await r.json();if(!r.ok)throw new Error(d.detail||'Request failed');return d}
async function copyText(text,button){try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(text);else{const a=document.createElement('textarea');a.value=text;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove()}button.textContent='Copied ✓';button.classList.add('copied');setTimeout(()=>{button.textContent='Copy';button.classList.remove('copied')},1300)}catch{button.textContent='Select text';setTimeout(()=>button.textContent='Copy',1500)}}
function section(parent,title,value){if(value===undefined||value===null||value===''||(Array.isArray(value)&&!value.length))return;const text=typeof value==='string'?value:JSON.stringify(value,null,2);const box=el('section','data-box');const head=el('div','data-head');head.appendChild(el('h4','',title));const b=el('button','copy-btn','Copy');b.type='button';b.onclick=()=>copyText(text,b);head.appendChild(b);box.appendChild(head);box.appendChild(el('pre','',text));parent.appendChild(box)}
function fieldLines(fields){return fields.filter(([,v])=>v!==undefined&&v!==null&&v!=='').map(([k,v])=>k+': '+v).join('\n')}
function renderGig(gig,index){const search=gig.search||{};const card=el('article','gig');const main=el('div','gig-main');const left=el('div');const h=el('h3');const link=el('a','',gig.title||search.card_title||gig.url);link.href=gig.url;link.target='_blank';link.rel='noopener';h.appendChild(link);left.appendChild(h);const meta=el('div','meta');if(search.global_position)meta.appendChild(chip('Rank #'+search.global_position,'rank'));meta.appendChild(chip(search.is_sponsored?'Sponsored':'Organic',search.is_sponsored?'ad':''));if(search.page_number)meta.appendChild(chip('Page '+search.page_number+' · Pos '+search.page_position));if(search.organic_position)meta.appendChild(chip('Organic #'+search.organic_position));if(gig.seller_name||gig.seller_username)meta.appendChild(chip('Seller: '+(gig.seller_name||gig.seller_username)));if(gig.seller_level)meta.appendChild(chip(gig.seller_level));if(gig.rating)meta.appendChild(chip('★ '+gig.rating+(gig.review_count?' ('+gig.review_count+')':'')));if(search.seller_online)meta.appendChild(chip('Online'));if(gig.error)meta.appendChild(chip('Error'));left.appendChild(meta);main.appendChild(left);const price=el('div','price');price.appendChild(el('small','','Starting price'));price.appendChild(el('strong','',gig.starting_price_usd!=null?'$'+gig.starting_price_usd:'—'));main.appendChild(price);card.appendChild(main);
const details=el('details');details.open=index===0;details.appendChild(el('summary','','Structured sections aur copy options'));const body=el('div','detail-body');if(gig.error)section(body,'Fetch error',gig.error);section(body,'Search position',fieldLines([['Keyword',search.niche],['Global rank',search.global_position],['Organic rank',search.organic_position],['Sponsored rank',search.sponsored_position],['Page',search.page_number],['Page position',search.page_position],['Placement',search.is_sponsored?'Sponsored':'Organic'],['Card price',search.card_price],['Badges',(search.badges||[]).join(', ')]]));section(body,'Gig overview',fieldLines([['Title',gig.title],['URL',gig.url],['Rating',gig.rating],['Review count',gig.review_count],['Starting price USD',gig.starting_price_usd],['Hourly rate USD',gig.hourly_rate_usd],['Categories',(gig.category_path||[]).join(' > ')],['Gallery items',gig.gallery_count],['Video',gig.has_video?'Yes':'No'],['Fetched at',gig.fetched_at]]));section(body,'Seller details',fieldLines([['Name',gig.seller_name],['Username',gig.seller_username],['Level',gig.seller_level],['Country',gig.seller_country],['Member since',gig.member_since],['Response time',gig.average_response_time],['Last delivery',gig.last_delivery]]));section(body,'Meta description',gig.meta_description);section(body,'About / service description',gig.about_text);section(body,'Structured packages',gig.packages);section(body,'Raw packages text',gig.packages_text);section(body,'FAQs',gig.faqs);section(body,'Raw FAQ text',gig.faq_text);section(body,'Review summary',gig.review_summary);section(body,'Visible reviews',gig.visible_reviews);section(body,'Raw reviews text',gig.reviews_text);section(body,'Related tags',gig.related_tags);section(body,'Media URLs',gig.media_urls);section(body,'Structured JSON-LD',gig.json_ld);section(body,'Raw visible page text',gig.raw_visible_text);details.appendChild(body);card.appendChild(details);return card}
function renderJob(job){$('jobPanel').classList.add('show');$('jobTitle').textContent=job.niche+' crawl';$('jobId').textContent=job.id;$('stage').textContent=job.stage||job.status;const p=Math.max(0,Math.min(100,Number(job.progress_percent||0)));$('progressBar').style.width=p+'%';$('mProgress').textContent=p.toFixed(1)+'%';$('mPages').textContent=job.pages_scanned||0;$('mDiscovered').textContent=job.discovered_count||0;$('mProcessed').textContent=job.processed_count||0;$('mSuccess').textContent=job.success_count||0;$('mFailed').textContent=job.failed_count||0;$('cancel').style.display=['queued','running','cancelling'].includes(job.status)?'inline-flex':'none';const available=job.available_results?' · Fiverr showed '+job.available_results+' total results':'';$('jobMessage').textContent=(job.discovery_source||'Waiting for discovery')+available;if(job.error){$('jobMessage').textContent=job.error;$('jobMessage').classList.add('error')}else $('jobMessage').classList.remove('error');$('warnings').replaceChildren();for(const w of(job.warnings||[]))$('warnings').appendChild(el('div','warning',w))}
async function pollJob(){if(!currentJobId)return;try{const job=await api('/api/jobs/'+currentJobId);renderJob(job);if(['completed','cancelled','failed','interrupted'].includes(job.status)){clearInterval(pollTimer);pollTimer=null;$('submit').disabled=false;$('submit').textContent='Start background job';if(job.status==='completed'||job.status==='cancelled'){showSummary(job);await loadResults(0)}localStorage.removeItem('fiverr-current-job')}}catch(e){$('jobMessage').textContent=e.message;$('jobMessage').classList.add('error')}}
function showSummary(job){$('summary').classList.add('show');$('summaryTitle').textContent=job.niche+' results';$('summaryMeta').textContent=(job.success_count||0)+' successful · '+(job.failed_count||0)+' failed · '+(job.discovered_count||0)+' discovered';$('downloads').replaceChildren();for(const[label,href]of Object.entries(job.downloads||{})){const a=el('a','button',label.toUpperCase()+' download');a.href=href;$('downloads').appendChild(a)}}
async function loadResults(offset){if(!currentJobId)return;const data=await api('/api/jobs/'+currentJobId+'/results?offset='+offset+'&limit='+PAGE_SIZE);currentOffset=data.offset;currentTotal=data.total;$('results').replaceChildren();data.results.forEach((gig,i)=>$('results').appendChild(renderGig(gig,i)));$('pagerWrap').classList.toggle('show',data.total>0);const from=data.total?data.offset+1:0,to=Math.min(data.offset+data.results.length,data.total);$('pagerInfo').textContent='Showing '+from+'–'+to+' of '+data.total;$('prev').disabled=data.offset<=0;$('next').disabled=!data.has_more}
$('prev').onclick=()=>loadResults(Math.max(0,currentOffset-PAGE_SIZE));$('next').onclick=()=>loadResults(currentOffset+PAGE_SIZE);
$('cancel').onclick=async()=>{if(!currentJobId)return;$('cancel').disabled=true;try{const job=await api('/api/jobs/'+currentJobId+'/cancel',{method:'POST'});renderJob(job)}catch(e){$('jobMessage').textContent=e.message}finally{$('cancel').disabled=false}};
$('form').addEventListener('submit',async e=>{e.preventDefault();$('submit').disabled=true;$('submit').textContent='Starting…';$('results').replaceChildren();$('summary').classList.remove('show');$('pagerWrap').classList.remove('show');try{const job=await api('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({niche:$('niche').value,limit:Number($('limit').value)})});currentJobId=job.id;localStorage.setItem('fiverr-current-job',currentJobId);renderJob(job);clearInterval(pollTimer);pollTimer=setInterval(pollJob,1500);await pollJob()}catch(e){$('jobPanel').classList.add('show');$('jobMessage').textContent=e.message;$('jobMessage').classList.add('error');$('submit').disabled=false;$('submit').textContent='Start background job'}});
(async()=>{const saved=localStorage.getItem('fiverr-current-job');if(saved){currentJobId=saved;$('submit').disabled=true;$('submit').textContent='Job running…';await pollJob();if($('submit').disabled&&!pollTimer)pollTimer=setInterval(pollJob,1500)}})();
</script></body></html>"""
