# Fiverr Market Crawler — Phase 1

Phase 1 is the persistent data foundation for a future Fiverr market-intelligence system. Enter a niche such as **Looker Studio** and the app starts a background crawl of up to 500 public Fiverr gigs.

## Phase 1 features

- Background jobs: the HTTP request returns immediately
- Live progress: stage, pages, discovered, processed, success and failure counts
- Fiverr search pagination up to 500 unique gig URLs
- Duplicate URL removal across pages
- Search snapshot fields:
  - search page and page position
  - global observed rank
  - organic rank
  - sponsored rank
  - sponsored/organic label
  - seller online flag
  - search-card title, seller, badge, rating, reviews, price and thumbnail
- Rich public gig parsing:
  - title, seller/profile fields and categories
  - Basic/Standard/Premium package objects
  - raw package section
  - FAQ question/answer objects
  - review summary and rating distribution
  - visible review objects, price, duration, buyer country and seller response
  - tags, gallery/media URLs, video flag and hourly rate
  - raw visible text and JSON-LD when available
- SQLite persistence and historical job snapshots
- Incremental saving after every fetched gig
- Retry with exponential backoff
- Job cancellation
- Paginated result UI (20 cards at a time)
- Per-section copy buttons
- JSON and CSV exports, including partial exports for cancelled jobs
- Interrupted-job recovery after a server restart

## Data boundaries

The crawler uses public pages only. It does not bypass login, CAPTCHA, access controls, private reviews, Success Score details, CTR/CR analytics, briefs, or buyer-personalization data. Reader mode sends each public URL to the third-party `r.jina.ai` service. Do not enter private or credential-bearing URLs.

Observed rank is a snapshot for that public session, not a universal Fiverr leaderboard. Search results can vary by time, geography, currency, buyer history and Fiverr experiments.

## Installation

Python 3.11+ recommended.

### Windows

```bat
cd fiverr-niche-fetcher
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
run.bat
```

### macOS/Linux

```bash
cd fiverr-niche-fetcher
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
chmod +x run.sh
./run.sh
```

Open:

```text
http://127.0.0.1:8000
```

Playwright/Chromium is no longer required for the default Phase 1 reader workflow.

## Storage

Generated files:

```text
data/fiverr_phase1.db     SQLite job/rank/snapshot database
data/exports/<job>.json   Complete structured export
data/exports/<job>.csv    Flat analysis-ready export
```

The database uses WAL mode and stores:

- `jobs` — state and progress
- `search_results` — position/card snapshots per keyword crawl
- `gig_snapshots` — full parsed page result per job
- `gigs` — latest known public record per canonical gig URL

## REST API

### Start background job

```http
POST /api/jobs
Content-Type: application/json

{
  "niche": "Looker Studio",
  "limit": 500
}
```

Legacy `POST /api/fetch` starts the same background job.

### Job status/progress

```http
GET /api/jobs/{job_id}
```

### Paginated results

```http
GET /api/jobs/{job_id}/results?offset=0&limit=20
```

### Cancel

```http
POST /api/jobs/{job_id}/cancel
```

### Recent jobs

```http
GET /api/jobs?limit=20
```

### Health

```http
GET /api/health
```

## Configuration

| Variable | Default | Purpose |
|---|---:|---|
| `MAX_ACTIVE_JOBS` | `1` | Simultaneous niche jobs; hard cap 3 |
| `MAX_CONCURRENCY` | `2` | Concurrent gig-page requests; hard cap 5 |
| `REQUEST_DELAY_SECONDS` | `2.0` | Delay after each gig fetch |
| `MAX_SEARCH_PAGES` | `30` | Paginated result pages; hard cap 50 |
| `SEARCH_PAGE_DELAY_SECONDS` | `0.75` | Delay between search pages |
| `RETRY_COUNT` | `3` | Retry count for transient HTTP failures |
| `RETRY_BASE_DELAY_SECONDS` | `1.0` | Exponential retry base |
| `READER_TIMEOUT_SECONDS` | `90` | Reader request timeout |
| `ALLOW_READER_FALLBACK` | `true` | Required public-reader mode switch |

## Tests

```bash
python -m unittest discover -s tests -v
```

Tests cover URL normalization, search position/sponsored parsing, package tables, FAQs, review objects and SQLite persistence/recovery.

## Project files

```text
fiverr-niche-fetcher/
├── app.py                 FastAPI API + local UI
├── fiverr_fetcher.py      discovery, parsing, retries and crawl workers
├── job_manager.py         background jobs, progress, cancellation and exports
├── storage.py             SQLite schema/repository
├── requirements.txt
├── .env.example
├── run.bat
├── run.sh
├── tests/
└── data/
```

## Operational note

A 500-gig crawl can take a long time because each detail page is fetched individually with low concurrency and delays. Keep the server running until the job completes. Use cancellation if you need a partial export. Follow Fiverr's Terms, robots policy and applicable law.
