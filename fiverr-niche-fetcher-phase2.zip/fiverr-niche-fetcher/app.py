from __future__ import annotations

import csv
import io
import json
import re
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from pydantic import BaseModel, Field, field_validator

from job_manager import JobManager
from market_analyzer import MarketAnalyzer
from storage import Storage

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = DATA_DIR / "exports"
DATA_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

storage = Storage(DATA_DIR / "fiverr_phase1.db")
manager = JobManager(storage, OUTPUT_DIR)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield
    await manager.shutdown()


app = FastAPI(
    title="Fiverr Market Intelligence — Phase 2",
    version="3.0.0",
    description="Background public-market crawler plus deterministic no-LLM analytics.",
    lifespan=lifespan,
)


class FetchRequest(BaseModel):
    niche: str = Field(min_length=2, max_length=100)
    limit: int = Field(default=5, ge=1, le=500)

    @field_validator("niche")
    @classmethod
    def clean_niche(cls, value: str) -> str:
        value = " ".join(value.split()).strip()
        if len(value) < 2:
            raise ValueError("Niche kam az kam 2 characters ka hona chahiye.")
        return value


@app.get("/", response_class=HTMLResponse)
async def home() -> str:
    return INDEX_HTML


@app.get("/api/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "phase": 2,
        "llm_enabled": False,
        "database": str(storage.path.name),
    }


@app.post("/api/jobs", status_code=202)
async def create_job(request: FetchRequest) -> dict[str, Any]:
    return manager.start_job(request.niche, request.limit)


# Backwards-compatible route. It now starts a background job instead of holding
# one HTTP connection open for a potentially long 500-gig crawl.
@app.post("/api/fetch", status_code=202)
async def fetch_niche(request: FetchRequest) -> dict[str, Any]:
    return manager.start_job(request.niche, request.limit)


@app.get("/api/jobs")
async def list_jobs(limit: int = Query(default=20, ge=1, le=100)) -> dict[str, Any]:
    jobs = manager.list_jobs(limit)
    return {"jobs": jobs, "count": len(jobs)}


@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/api/jobs/{job_id}/results")
async def get_job_results(
    job_id: str,
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    results, total = storage.get_job_results(job_id, offset=offset, limit=limit)
    return {
        "job_id": job_id,
        "status": job["status"],
        "offset": offset,
        "limit": limit,
        "total": total,
        "has_more": offset + len(results) < total,
        "results": results,
    }


@app.get("/api/jobs/{job_id}/analysis")
async def get_job_analysis(job_id: str) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    if job["status"] in {"queued", "running", "cancelling"}:
        raise HTTPException(status_code=409, detail="Analysis will be available when the crawl finishes")
    analysis = manager.analyze_job(job_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Analysis not available")
    return analysis


@app.post("/api/jobs/{job_id}/analysis/rebuild")
async def rebuild_job_analysis(job_id: str) -> dict[str, Any]:
    job = manager.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    if job["status"] in {"queued", "running", "cancelling"}:
        raise HTTPException(status_code=409, detail="Wait for the crawl to finish")
    analysis = manager.analyze_job(job_id, force=True)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Analysis not available")
    return analysis


@app.get("/api/jobs/{job_id}/analysis/{section}.csv")
async def export_analysis_section(job_id: str, section: str) -> StreamingResponse:
    allowed = {
        "overview", "rankings", "movement", "keywords", "clusters",
        "pricing", "packages", "competitors", "reviews", "gaps",
    }
    if section not in allowed:
        raise HTTPException(status_code=400, detail="Unsupported analysis section")
    analysis = manager.analyze_job(job_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Analysis not available")
    rows = MarketAnalyzer.export_rows(analysis, section)
    output = io.StringIO()
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["message"]
        rows = [{"message": "No rows available for this section"}]
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        clean = {
            key: json.dumps(value, ensure_ascii=False)
            if isinstance(value, (dict, list)) else value
            for key, value in row.items()
        }
        writer.writerow(clean)
    filename = f"{job_id}-{section}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str) -> dict[str, Any]:
    job = manager.cancel_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


@app.get("/download/{filename}")
async def download(filename: str) -> FileResponse:
    if not re.fullmatch(r"[A-Za-z0-9_-]+\.(json|csv)", filename):
        raise HTTPException(status_code=400, detail="Invalid filename")
    path = OUTPUT_DIR / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Export not found")
    media_type = "application/json" if path.suffix == ".json" else "text/csv"
    return FileResponse(path, filename=filename, media_type=media_type)


INDEX_HTML = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Fiverr Market Intelligence — Phase 2</title>
  <style>
    :root{--bg:#07120e;--panel:#0f2018;--panel2:#14281f;--line:#29483a;--text:#f3fbf6;--muted:#a5bdb1;--green:#1dbf73;--green2:#75ecb2;--danger:#ff7979;--warn:#ffd37a;--blue:#7cb7ff}
    *{box-sizing:border-box} body{margin:0;min-height:100vh;color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:radial-gradient(circle at 12% 4%,rgba(29,191,115,.16),transparent 30rem),radial-gradient(circle at 92% 24%,rgba(124,183,255,.08),transparent 25rem),var(--bg)}
    .wrap{width:min(1180px,calc(100% - 32px));margin:auto;padding:50px 0 80px}.eyebrow{color:var(--green2);font-size:12px;font-weight:900;letter-spacing:.15em;text-transform:uppercase}h1{margin:9px 0 12px;max-width:900px;font-size:clamp(36px,6vw,68px);line-height:1;letter-spacing:-.05em}.lead{max-width:780px;color:var(--muted);font-size:18px;line-height:1.6}
    .search-card{margin-top:30px;padding:20px;display:grid;grid-template-columns:1fr 150px auto;gap:12px;border:1px solid var(--line);background:rgba(15,32,24,.9);border-radius:18px;box-shadow:0 22px 65px rgba(0,0,0,.3)}label{display:block;margin:0 0 8px 2px;color:var(--muted);font-size:12px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}input,select,button,a.button{font:inherit}input,select{width:100%;height:50px;padding:0 15px;color:var(--text);background:#081710;border:1px solid var(--line);border-radius:12px;outline:none}input:focus,select:focus{border-color:var(--green);box-shadow:0 0 0 3px rgba(29,191,115,.12)}
    button,a.button{height:50px;align-self:end;display:inline-flex;align-items:center;justify-content:center;padding:0 21px;border:0;border-radius:12px;color:#03130a;background:var(--green);font-weight:900;text-decoration:none;cursor:pointer}button:hover,a.button:hover{background:var(--green2)}button:disabled{opacity:.55;cursor:not-allowed}.secondary{color:var(--text)!important;background:var(--panel2)!important;border:1px solid var(--line)!important}.danger{color:#fff!important;background:#672c32!important;border:1px solid #a94952!important}.fine{margin:12px 3px 0;color:#7f9a8d;font-size:13px;line-height:1.55}
    .job-panel{display:none;margin-top:24px;padding:20px;border:1px solid var(--line);border-radius:17px;background:var(--panel)}.job-panel.show{display:block}.job-top{display:flex;justify-content:space-between;align-items:flex-start;gap:15px}.job-top h2{margin:0 0 5px;font-size:21px}.job-id{color:#7f9a8d;font:12px ui-monospace,monospace;overflow-wrap:anywhere}.stage{display:inline-flex;margin-top:8px;padding:5px 9px;border-radius:999px;color:var(--green2);background:#092017;border:1px solid #295440;font-size:12px;font-weight:800;text-transform:capitalize}.progress-track{height:12px;margin:18px 0 10px;overflow:hidden;border:1px solid #2b4b3d;border-radius:999px;background:#07120e}.progress-bar{height:100%;width:0;background:linear-gradient(90deg,var(--green),var(--green2));transition:width .35s ease}.metrics{display:grid;grid-template-columns:repeat(6,1fr);gap:9px}.metric{padding:11px;background:#091710;border:1px solid #233d32;border-radius:11px}.metric small{display:block;color:#82998e;font-size:11px;text-transform:uppercase}.metric strong{display:block;margin-top:3px;font-size:18px}.job-message{margin:12px 0 0;color:var(--muted);font-size:13px}.warning{margin:10px 0;padding:11px 13px;border:1px solid rgba(255,211,122,.35);border-radius:10px;color:var(--warn);background:rgba(255,211,122,.06);font-size:13px}.error{color:var(--danger)!important}
    .summary{display:none;margin:28px 0 15px;align-items:center;justify-content:space-between;gap:14px}.summary.show{display:flex}.summary h2{margin:0;font-size:25px}.summary p{margin:4px 0 0;color:var(--muted)}.downloads,.pager{display:flex;gap:8px;flex-wrap:wrap}.downloads a.button,.pager button{height:39px;padding:0 14px;color:var(--text);background:var(--panel2);border:1px solid var(--line);font-size:13px}.pager-wrap{display:none;margin:12px 0 18px;align-items:center;justify-content:space-between;gap:12px;color:var(--muted);font-size:13px}.pager-wrap.show{display:flex}
    .results{display:grid;gap:14px}.gig{overflow:hidden;border:1px solid var(--line);border-radius:17px;background:rgba(15,32,24,.92)}.gig-main{padding:19px;display:grid;grid-template-columns:1fr auto;gap:18px}.gig h3{margin:0 0 9px;font-size:19px;line-height:1.35}.gig h3 a{color:var(--text);text-decoration:none}.gig h3 a:hover{color:var(--green2)}.meta{display:flex;gap:7px;flex-wrap:wrap}.chip{padding:6px 9px;color:var(--muted);background:#081710;border:1px solid var(--line);border-radius:999px;font-size:12px}.chip.rank{color:#05140c;background:var(--green2);border-color:var(--green2);font-weight:900}.chip.ad{color:#1b1100;background:var(--warn);border-color:var(--warn);font-weight:900}.price{min-width:110px;text-align:right}.price small{display:block;color:var(--muted)}.price strong{font-size:24px;color:var(--green2)}details{border-top:1px solid var(--line)}summary{padding:14px 20px;color:var(--muted);font-weight:750;cursor:pointer}.detail-body{padding:4px 20px 20px;display:grid;gap:12px}.data-box{overflow:hidden;border:1px solid #28483a;border-radius:13px;background:#08130e}.data-head{min-height:45px;padding:8px 10px 8px 14px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #1e352b;background:#102119}.data-head h4{margin:0;color:var(--green2);font-size:14px}button.copy-btn{width:auto;min-width:72px;height:30px;align-self:auto;padding:0 10px;color:var(--text);background:#183025;border:1px solid #365c4b;border-radius:8px;font-size:12px}button.copy-btn:hover,button.copy-btn.copied{color:#03130a;background:var(--green2)}pre{margin:0;max-height:360px;overflow:auto;padding:14px;white-space:pre-wrap;overflow-wrap:anywhere;color:#d9e9e0;background:#08130e;font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}
    .analysis-panel{display:none;margin:24px 0;border:1px solid var(--line);border-radius:18px;background:rgba(15,32,24,.94);overflow:hidden}.analysis-panel.show{display:block}.analysis-head{padding:18px 20px;display:flex;align-items:flex-start;justify-content:space-between;gap:15px;border-bottom:1px solid var(--line)}.analysis-head h2{margin:0 0 5px;font-size:23px}.analysis-head p{margin:0;color:var(--muted);font-size:13px}.tabs{display:flex;gap:7px;padding:12px 14px;overflow-x:auto;border-bottom:1px solid var(--line);background:#0a1912}.tabs button{height:35px;min-width:max-content;padding:0 12px;align-self:auto;color:var(--muted);background:#102219;border:1px solid #29483a;border-radius:9px;font-size:12px}.tabs button.active{color:#03130a;background:var(--green2);border-color:var(--green2)}.analysis-content{padding:18px;display:grid;gap:16px}.analytics-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.analytics-card{padding:14px;border:1px solid #29483a;border-radius:12px;background:#081710}.analytics-card small{display:block;color:#82998e;font-size:11px;text-transform:uppercase}.analytics-card strong{display:block;margin-top:5px;color:var(--green2);font-size:22px}.analytics-card span{display:block;margin-top:3px;color:var(--muted);font-size:12px}.panel-block{padding:14px;border:1px solid #29483a;border-radius:13px;background:#091710}.panel-block h3{margin:0 0 11px;font-size:16px}.table-wrap{overflow:auto;max-height:560px;border:1px solid #29483a;border-radius:11px}.analysis-table{width:100%;border-collapse:collapse;min-width:760px;font-size:12px}.analysis-table th{position:sticky;top:0;z-index:1;padding:10px;text-align:left;color:var(--green2);background:#102219;border-bottom:1px solid #355a49;cursor:pointer;white-space:nowrap}.analysis-table td{padding:9px 10px;color:#d8e8df;border-bottom:1px solid #1d342a;vertical-align:top}.analysis-table tr:hover td{background:#0d2017}.bar-list{display:grid;gap:8px}.bar-row{display:grid;grid-template-columns:minmax(110px,220px) 1fr 55px;gap:9px;align-items:center;font-size:12px}.bar-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted)}.bar-track{height:9px;overflow:hidden;border-radius:99px;background:#07120e;border:1px solid #29483a}.bar-fill{height:100%;background:linear-gradient(90deg,var(--green),var(--blue));border-radius:99px}.bar-value{text-align:right;color:var(--text)}.analysis-note{padding:12px;border-left:3px solid var(--blue);color:var(--muted);background:rgba(124,183,255,.06);font-size:13px;line-height:1.55}.filter-row{display:flex;gap:9px;flex-wrap:wrap}.filter-row input,.filter-row select{width:auto;min-width:150px;height:40px}.empty{padding:24px;text-align:center;color:var(--muted)}
    footer{margin-top:42px;color:#6e887b;font-size:13px;line-height:1.6}@media(max-width:800px){.search-card{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,1fr)}.analytics-grid{grid-template-columns:repeat(2,1fr)}.job-top,.summary,.gig-main,.pager-wrap,.analysis-head{align-items:flex-start;flex-direction:column;display:flex}.summary,.pager-wrap{display:none}.summary.show,.pager-wrap.show{display:flex}.price{text-align:left}}
  </style>
</head>
<body><main class="wrap">
  <div class="eyebrow">Phase 2 · No-LLM market intelligence</div>
  <h1>Fiverr Market Intelligence</h1>
  <p class="lead">Public Fiverr market ko crawl karke rank snapshots, keyword patterns, pricing, packages, competitors, reviews aur transparent opportunity gaps analyze karein—without any LLM.</p>
  <form id="form" class="search-card">
    <div><label for="niche">Niche / keyword</label><input id="niche" value="Looker Studio" minlength="2" maxlength="100" required></div>
    <div><label for="limit">Maximum gigs</label><select id="limit"><option>3</option><option selected>5</option><option>10</option><option>25</option><option>50</option><option>100</option><option>250</option><option>500</option></select></div>
    <button id="submit" type="submit">Start background job</button>
  </form>
  <p class="fine">500 gigs background job mein run hoti hain. Crawl ke baad Phase 2 analytics automatically calculate hoti hain. Public URLs only; no LLM, low concurrency, retries, deduplication aur rate limiting enabled hain.</p>

  <section id="jobPanel" class="job-panel">
    <div class="job-top"><div><h2 id="jobTitle">Crawl job</h2><div id="jobId" class="job-id"></div><span id="stage" class="stage">queued</span></div><button id="cancel" class="danger" type="button">Cancel job</button></div>
    <div class="progress-track"><div id="progressBar" class="progress-bar"></div></div>
    <div class="metrics">
      <div class="metric"><small>Progress</small><strong id="mProgress">0%</strong></div>
      <div class="metric"><small>Pages</small><strong id="mPages">0</strong></div>
      <div class="metric"><small>Discovered</small><strong id="mDiscovered">0</strong></div>
      <div class="metric"><small>Processed</small><strong id="mProcessed">0</strong></div>
      <div class="metric"><small>Success</small><strong id="mSuccess">0</strong></div>
      <div class="metric"><small>Failed</small><strong id="mFailed">0</strong></div>
    </div>
    <p id="jobMessage" class="job-message"></p><div id="warnings"></div>
  </section>

  <section id="summary" class="summary"><div><h2 id="summaryTitle">Results</h2><p id="summaryMeta"></p></div><div id="downloads" class="downloads"></div></section>

  <section id="analysisPanel" class="analysis-panel">
    <div class="analysis-head"><div><h2>Phase 2 Market Intelligence</h2><p id="analysisMeta">Deterministic analytics · No LLM</p></div><a id="analysisCsv" class="button secondary" href="#">Download tab CSV</a></div>
    <div id="analysisTabs" class="tabs">
      <button type="button" data-tab="overview" class="active">Overview</button>
      <button type="button" data-tab="rankings">Rankings</button>
      <button type="button" data-tab="movement">Movement</button>
      <button type="button" data-tab="keywords">Keywords</button>
      <button type="button" data-tab="clusters">Clusters</button>
      <button type="button" data-tab="pricing">Pricing</button>
      <button type="button" data-tab="packages">Packages</button>
      <button type="button" data-tab="competitors">Competitors</button>
      <button type="button" data-tab="reviews">Reviews</button>
      <button type="button" data-tab="gaps">Market Gaps</button>
    </div>
    <div id="analysisContent" class="analysis-content"></div>
  </section>

  <div id="pagerWrap" class="pager-wrap"><span id="pagerInfo"></span><div class="pager"><button id="prev" class="secondary" type="button">Previous</button><button id="next" class="secondary" type="button">Next</button></div></div>
  <section id="results" class="results"></section>
  <footer>Phase 2 uses deterministic statistics, n-grams, lexicons and transparent proxy formulas—no LLM. Search output is personalized/dynamic, and opportunity scores are research diagnostics rather than Fiverr search volume or secret ranking weights.</footer>
</main>
<script>
const $=id=>document.getElementById(id); const PAGE_SIZE=20;
let currentJobId=null,pollTimer=null,currentOffset=0,currentTotal=0,analysisData=null,activeAnalysisTab='overview';
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined&&text!==null)n.textContent=text;return n}
function chip(text,extra=''){return el('span','chip '+extra,text)}
async function api(url,options={}){const r=await fetch(url,options);const d=await r.json();if(!r.ok)throw new Error(d.detail||'Request failed');return d}
async function copyText(text,button){try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText(text);else{const a=document.createElement('textarea');a.value=text;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove()}button.textContent='Copied ✓';button.classList.add('copied');setTimeout(()=>{button.textContent='Copy';button.classList.remove('copied')},1300)}catch{button.textContent='Select text';setTimeout(()=>button.textContent='Copy',1500)}}
function section(parent,title,value){if(value===undefined||value===null||value===''||(Array.isArray(value)&&!value.length))return;const text=typeof value==='string'?value:JSON.stringify(value,null,2);const box=el('section','data-box');const head=el('div','data-head');head.appendChild(el('h4','',title));const b=el('button','copy-btn','Copy');b.type='button';b.onclick=()=>copyText(text,b);head.appendChild(b);box.appendChild(head);box.appendChild(el('pre','',text));parent.appendChild(box)}
function fieldLines(fields){return fields.filter(([,v])=>v!==undefined&&v!==null&&v!=='').map(([k,v])=>k+': '+v).join('\n')}
function renderGig(gig,index){const search=gig.search||{};const card=el('article','gig');const main=el('div','gig-main');const left=el('div');const h=el('h3');const link=el('a','',gig.title||search.card_title||gig.url);link.href=gig.url;link.target='_blank';link.rel='noopener';h.appendChild(link);left.appendChild(h);const meta=el('div','meta');if(search.global_position)meta.appendChild(chip('Rank #'+search.global_position,'rank'));meta.appendChild(chip(search.is_sponsored?'Sponsored':'Organic',search.is_sponsored?'ad':''));if(search.page_number)meta.appendChild(chip('Page '+search.page_number+' · Pos '+search.page_position));if(search.organic_position)meta.appendChild(chip('Organic #'+search.organic_position));if(gig.seller_name||gig.seller_username)meta.appendChild(chip('Seller: '+(gig.seller_name||gig.seller_username)));if(gig.seller_level)meta.appendChild(chip(gig.seller_level));if(gig.rating)meta.appendChild(chip('★ '+gig.rating+(gig.review_count?' ('+gig.review_count+')':'')));if(search.seller_online)meta.appendChild(chip('Online'));if(gig.error)meta.appendChild(chip('Error'));left.appendChild(meta);main.appendChild(left);const price=el('div','price');price.appendChild(el('small','','Starting price'));price.appendChild(el('strong','',gig.starting_price_usd!=null?'$'+gig.starting_price_usd:'—'));main.appendChild(price);card.appendChild(main);
const details=el('details');details.open=index===0;details.appendChild(el('summary','','Structured sections aur copy options'));const body=el('div','detail-body');if(gig.error)section(body,'Fetch error',gig.error);section(body,'Search position',fieldLines([['Keyword',search.niche],['Global rank',search.global_position],['Organic rank',search.organic_position],['Sponsored rank',search.sponsored_position],['Page',search.page_number],['Page position',search.page_position],['Placement',search.is_sponsored?'Sponsored':'Organic'],['Card price',search.card_price],['Badges',(search.badges||[]).join(', ')]]));section(body,'Gig overview',fieldLines([['Title',gig.title],['URL',gig.url],['Rating',gig.rating],['Review count',gig.review_count],['Starting price USD',gig.starting_price_usd],['Hourly rate USD',gig.hourly_rate_usd],['Categories',(gig.category_path||[]).join(' > ')],['Gallery items',gig.gallery_count],['Video',gig.has_video?'Yes':'No'],['Fetched at',gig.fetched_at]]));section(body,'Seller details',fieldLines([['Name',gig.seller_name],['Username',gig.seller_username],['Level',gig.seller_level],['Country',gig.seller_country],['Member since',gig.member_since],['Response time',gig.average_response_time],['Last delivery',gig.last_delivery]]));section(body,'Meta description',gig.meta_description);section(body,'About / service description',gig.about_text);section(body,'Structured packages',gig.packages);section(body,'Raw packages text',gig.packages_text);section(body,'FAQs',gig.faqs);section(body,'Raw FAQ text',gig.faq_text);section(body,'Review summary',gig.review_summary);section(body,'Visible reviews',gig.visible_reviews);section(body,'Raw reviews text',gig.reviews_text);section(body,'Related tags',gig.related_tags);section(body,'Media URLs',gig.media_urls);section(body,'Structured JSON-LD',gig.json_ld);section(body,'Raw visible page text',gig.raw_visible_text);details.appendChild(body);card.appendChild(details);return card}
function fmt(v){if(v===undefined||v===null||v==='')return '—';if(typeof v==='number')return Number.isInteger(v)?String(v):v.toFixed(2);if(Array.isArray(v))return v.join(', ');return String(v)}
function analyticsCard(label,value,note=''){const c=el('div','analytics-card');c.appendChild(el('small','',label));c.appendChild(el('strong','',fmt(value)));if(note)c.appendChild(el('span','',note));return c}
function block(parent,title){const b=el('section','panel-block');b.appendChild(el('h3','',title));parent.appendChild(b);return b}
function renderBars(parent,rows,labelKey='label',valueKey='count',limit=15){const data=(rows||[]).slice(0,limit);if(!data.length){parent.appendChild(el('div','empty','No data available'));return}const max=Math.max(...data.map(r=>Number(r[valueKey]||0)),1);const list=el('div','bar-list');for(const row of data){const line=el('div','bar-row');line.appendChild(el('div','bar-label',fmt(row[labelKey])));const track=el('div','bar-track');const fill=el('div','bar-fill');fill.style.width=(100*Number(row[valueKey]||0)/max)+'%';track.appendChild(fill);line.appendChild(track);line.appendChild(el('div','bar-value',fmt(row[valueKey])));list.appendChild(line)}parent.appendChild(list)}
function renderTable(parent,rows,columns,maxRows=200){const source=(rows||[]).slice();if(!source.length){parent.appendChild(el('div','empty','No rows available'));return}const wrap=el('div','table-wrap');const table=el('table','analysis-table');const thead=document.createElement('thead');const headRow=document.createElement('tr');const tbody=document.createElement('tbody');let sortKey=null,sortAsc=true;function draw(){tbody.replaceChildren();const data=source.slice();if(sortKey)data.sort((a,b)=>{const av=a[sortKey],bv=b[sortKey];if(av===bv)return 0;if(av===undefined||av===null)return 1;if(bv===undefined||bv===null)return -1;if(typeof av==='number'&&typeof bv==='number')return sortAsc?av-bv:bv-av;return sortAsc?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av))});for(const row of data.slice(0,maxRows)){const tr=document.createElement('tr');for(const [key] of columns){const td=document.createElement('td');const value=row[key];if(key==='url'&&value){const a=el('a','', 'Open');a.href=value;a.target='_blank';a.rel='noopener';a.style.color='var(--green2)';td.appendChild(a)}else td.textContent=fmt(value);tr.appendChild(td)}tbody.appendChild(tr)}}for(const [key,label] of columns){const th=el('th','',label);th.onclick=()=>{if(sortKey===key)sortAsc=!sortAsc;else{sortKey=key;sortAsc=true}draw()};headRow.appendChild(th)}thead.appendChild(headRow);table.appendChild(thead);table.appendChild(tbody);wrap.appendChild(table);parent.appendChild(wrap);draw()}
function renderOverview(root){const o=analysisData.overview||{};const g=el('div','analytics-grid');g.appendChild(analyticsCard('Sampled gigs',o.sampled_gigs));g.appendChild(analyticsCard('Available results',o.available_results));g.appendChild(analyticsCard('Unique sellers',o.unique_sellers));g.appendChild(analyticsCard('Sponsored share',(o.sponsored_share_pct||0)+'%'));g.appendChild(analyticsCard('Median price','$'+fmt((o.starting_price||{}).median)));g.appendChild(analyticsCard('Average rating',fmt((o.rating||{}).mean)));g.appendChild(analyticsCard('Median reviews',fmt((o.review_count||{}).median)));g.appendChild(analyticsCard('Video share',(o.video_share_pct||0)+'%'));root.appendChild(g);const levels=block(root,'Seller levels');renderBars(levels,o.seller_levels);const countries=block(root,'Seller countries');renderBars(countries,o.seller_countries);const note=el('div','analysis-note','Public sample coverage: '+fmt(o.detail_coverage_pct)+'%. These are observed marketplace statistics, not private Fiverr analytics.');root.appendChild(note)}
function renderRankings(root){const r=analysisData.rankings||{};const top=block(root,'Observed ranking leaderboard');renderTable(top,r.top_gigs,[['global_position','Rank'],['organic_position','Organic'],['is_sponsored','Sponsored'],['title','Gig'],['seller','Seller'],['seller_level','Level'],['price','Price'],['rating','Rating'],['review_count','Reviews'],['url','Link']],100);const sellers=block(root,'Seller concentration');renderTable(sellers,r.seller_concentration,[['seller','Seller'],['seller_username','Username'],['gig_count','Gigs'],['best_rank','Best rank'],['average_rank','Avg rank'],['sponsored_count','Sponsored']],100)}
function renderMovement(root){const m=analysisData.rank_movement||{};if(!m.available){root.appendChild(el('div','analysis-note',m.reason||'A previous crawl is required.'));return}const g=el('div','analytics-grid');g.appendChild(analyticsCard('Common gigs',m.common_count));g.appendChild(analyticsCard('Gainers',m.gainers));g.appendChild(analyticsCard('Decliners',m.decliners));g.appendChild(analyticsCard('Unchanged',m.unchanged));root.appendChild(g);const b=block(root,'Rank changes');renderTable(b,m.movements,[['title','Gig'],['seller','Seller'],['previous_rank','Previous'],['current_rank','Current'],['change','Change'],['price_change','Price Δ'],['review_change','Reviews Δ'],['url','Link']],200);const n=block(root,'New gigs');renderTable(n,m.new_gigs,[['global_position','Rank'],['title','Gig'],['seller','Seller'],['price','Price'],['url','Link']],100)}
function renderKeywords(root){const k=analysisData.keywords||{};const intro=el('div','analysis-note','Phrases are extracted deterministically from public titles/tags. Click a table header to sort.');root.appendChild(intro);for(const [key,title] of [['bigrams','Two-word phrases'],['trigrams','Three-word phrases'],['title_starts','Title-start patterns'],['unigrams','Single terms'],['related_tags','Related tags']]){const b=block(root,title);renderTable(b,k[key],[['phrase','Phrase'],['gig_count','Gigs'],['share_pct','Share %'],['top_20_count','Top 20'],['average_rank','Avg rank'],['median_price','Median price'],['average_reviews','Avg reviews']],120)}}
function renderClusters(root){const b=block(root,'Deterministic keyword clusters');renderTable(b,analysisData.keyword_clusters,[['cluster','Cluster'],['phrases','Phrases'],['gig_count','Gigs'],['share_pct','Share %'],['average_rank','Avg rank'],['median_price','Median price']],100);root.appendChild(el('div','analysis-note','Cluster labels come from repeated shared tokens and Jaccard overlap—no LLM or semantic model is used.'))}
function renderPricing(root){const p=analysisData.pricing||{};const o=p.overall||{};const g=el('div','analytics-grid');for(const [label,key] of [['Minimum','min'],['Q1','q1'],['Median','median'],['Mean','mean'],['Q3','q3'],['P90','p90'],['Maximum','max'],['Listings','count']])g.appendChild(analyticsCard(label,key==='count'?o[key]:'$'+fmt(o[key])));root.appendChild(g);const hist=block(root,'Starting-price distribution');renderBars(hist,p.histogram,'label','count',30);const tiers=block(root,'Package tier statistics');const tierRows=Object.entries(p.package_tiers||{}).map(([segment,v])=>({segment,...v}));renderTable(tiers,tierRows,[['segment','Tier'],['count','Count'],['min','Min'],['q1','Q1'],['median','Median'],['mean','Mean'],['q3','Q3'],['max','Max']]);const seg=block(root,'Price by seller level');renderTable(seg,p.by_seller_level,[['segment','Level'],['count','Count'],['median','Median'],['mean','Mean'],['q1','Q1'],['q3','Q3'],['max','Max']])}
function renderPackages(root){const p=analysisData.packages||{};const g=el('div','analytics-grid');g.appendChild(analyticsCard('Gigs with packages',p.gigs_with_packages));for(const row of(p.tier_counts||[]))g.appendChild(analyticsCard(row.tier,row.count));root.appendChild(g);const matrix=block(root,'Feature matrix');renderTable(matrix,p.feature_matrix,[['feature','Feature'],['gig_count','Gigs'],['overall_coverage_pct','Coverage %'],['basic_count','Basic'],['standard_count','Standard'],['premium_count','Premium']],150);for(const [tier,rows] of Object.entries(p.delivery_patterns||{})){const b=block(root,tier+' delivery patterns');renderBars(b,rows)}}
function renderCompetitors(root){const controls=el('div','filter-row');const q=document.createElement('input');q.placeholder='Search title or seller';const level=document.createElement('select');for(const v of['All levels',...new Set((analysisData.competitors||[]).map(x=>x.seller_level).filter(Boolean))]){const op=el('option','',v);op.value=v;level.appendChild(op)}const placement=document.createElement('select');for(const v of['All placements','Organic','Sponsored']){const op=el('option','',v);op.value=v;placement.appendChild(op)}controls.append(q,level,placement);root.appendChild(controls);const holder=block(root,'Competitor explorer');function draw(){holder.querySelectorAll('.table-wrap,.empty').forEach(n=>n.remove());const term=q.value.toLowerCase();const rows=(analysisData.competitors||[]).filter(x=>(!term||((x.title||'')+' '+(x.seller||'')).toLowerCase().includes(term))&&(level.value==='All levels'||x.seller_level===level.value)&&(placement.value==='All placements'||(placement.value==='Sponsored')===Boolean(x.is_sponsored)));renderTable(holder,rows,[['global_position','Rank'],['title','Gig'],['seller','Seller'],['seller_level','Level'],['seller_country','Country'],['price','Price'],['rating','Rating'],['review_count','Reviews'],['has_video','Video'],['package_count','Packages'],['url','Link']],300)}q.oninput=draw;level.onchange=draw;placement.onchange=draw;draw()}
function renderReviews(root){const r=analysisData.reviews||{};const g=el('div','analytics-grid');g.appendChild(analyticsCard('Visible reviews',r.visible_reviews_analyzed));g.appendChild(analyticsCard('Average rating',r.average_visible_rating));g.appendChild(analyticsCard('Ongoing share',(r.ongoing_collaboration_share_pct||0)+'%'));g.appendChild(analyticsCard('Work-sample share',(r.work_sample_share_pct||0)+'%'));g.appendChild(analyticsCard('Seller-response share',(r.seller_response_share_pct||0)+'%'));root.appendChild(g);const sentiment=block(root,'Rule-based sentiment');renderBars(sentiment,r.sentiment,'label','count');const praise=block(root,'Most praised terms');renderBars(praise,r.praise_terms,'term','count');const concerns=block(root,'Concern terms');renderBars(concerns,r.concern_terms,'term','count');const phrases=block(root,'Repeated buyer phrases');renderTable(phrases,r.top_phrases,[['phrase','Phrase'],['review_count','Reviews'],['gig_count','Gigs']],100);const countries=block(root,'Buyer countries');renderBars(countries,r.buyer_countries)}
function renderGaps(root){const g=analysisData.market_gaps||{};root.appendChild(el('div','analysis-note',(g.formula||{}).warning||'Scores are public-data proxies.'));const opportunities=block(root,'Keyword opportunities');renderTable(opportunities,g.keyword_opportunities,[['phrase','Phrase'],['opportunity_score','Score'],['demand_proxy','Demand proxy'],['competition_proxy','Competition'],['price_potential','Price potential'],['gig_count','Gigs'],['median_price','Median price'],['evidence','Evidence']],100);const review=block(root,'Review-language gaps');renderTable(review,g.review_language_gaps,[['phrase','Buyer phrase'],['review_gig_count','Review gigs'],['title_gig_count','Title gigs'],['gap_type','Reason']],100);const offers=block(root,'Offer-feature gaps');renderTable(offers,g.offer_feature_gaps,[['feature','Feature'],['top_10_gig_count','Top-10 gigs'],['overall_gig_count','Overall gigs'],['overall_coverage_pct','Coverage %'],['gap_type','Reason']],100)}
function renderAnalysisTab(tab){activeAnalysisTab=tab;document.querySelectorAll('#analysisTabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));$('analysisCsv').href='/api/jobs/'+currentJobId+'/analysis/'+tab+'.csv';const root=$('analysisContent');root.replaceChildren();if(!analysisData){root.appendChild(el('div','empty','Analysis not loaded'));return}const renders={overview:renderOverview,rankings:renderRankings,movement:renderMovement,keywords:renderKeywords,clusters:renderClusters,pricing:renderPricing,packages:renderPackages,competitors:renderCompetitors,reviews:renderReviews,gaps:renderGaps};(renders[tab]||renderOverview)(root)}
async function loadAnalysis(){try{analysisData=await api('/api/jobs/'+currentJobId+'/analysis');$('analysisPanel').classList.add('show');$('analysisMeta').textContent='Generated '+analysisData.generated_at+' · '+(analysisData.methodology.llm_used?'LLM enabled':'No LLM · deterministic analytics');renderAnalysisTab(activeAnalysisTab)}catch(e){$('analysisPanel').classList.add('show');$('analysisContent').replaceChildren(el('div','analysis-note','Analysis unavailable: '+e.message))}}
document.querySelectorAll('#analysisTabs button').forEach(button=>button.onclick=()=>renderAnalysisTab(button.dataset.tab));
function renderJob(job){$('jobPanel').classList.add('show');$('jobTitle').textContent=job.niche+' crawl';$('jobId').textContent=job.id;$('stage').textContent=job.stage||job.status;const p=Math.max(0,Math.min(100,Number(job.progress_percent||0)));$('progressBar').style.width=p+'%';$('mProgress').textContent=p.toFixed(1)+'%';$('mPages').textContent=job.pages_scanned||0;$('mDiscovered').textContent=job.discovered_count||0;$('mProcessed').textContent=job.processed_count||0;$('mSuccess').textContent=job.success_count||0;$('mFailed').textContent=job.failed_count||0;$('cancel').style.display=['queued','running','cancelling'].includes(job.status)?'inline-flex':'none';const available=job.available_results?' · Fiverr showed '+job.available_results+' total results':'';$('jobMessage').textContent=(job.discovery_source||'Waiting for discovery')+available;if(job.error){$('jobMessage').textContent=job.error;$('jobMessage').classList.add('error')}else $('jobMessage').classList.remove('error');$('warnings').replaceChildren();for(const w of(job.warnings||[]))$('warnings').appendChild(el('div','warning',w))}
async function pollJob(){if(!currentJobId)return;try{const job=await api('/api/jobs/'+currentJobId);renderJob(job);if(['completed','cancelled','failed','interrupted'].includes(job.status)){clearInterval(pollTimer);pollTimer=null;$('submit').disabled=false;$('submit').textContent='Start background job';if(job.status==='completed'||job.status==='cancelled'){showSummary(job);await loadAnalysis();await loadResults(0)}localStorage.removeItem('fiverr-current-job')}}catch(e){clearInterval(pollTimer);pollTimer=null;localStorage.removeItem('fiverr-current-job');$('submit').disabled=false;$('submit').textContent='Start background job';$('jobMessage').textContent=e.message;$('jobMessage').classList.add('error')}}
function showSummary(job){$('summary').classList.add('show');$('summaryTitle').textContent=job.niche+' results';$('summaryMeta').textContent=(job.success_count||0)+' successful · '+(job.failed_count||0)+' failed · '+(job.discovered_count||0)+' discovered';$('downloads').replaceChildren();for(const[label,href]of Object.entries(job.downloads||{})){const a=el('a','button',label.toUpperCase()+' download');a.href=href;$('downloads').appendChild(a)}}
async function loadResults(offset){if(!currentJobId)return;const data=await api('/api/jobs/'+currentJobId+'/results?offset='+offset+'&limit='+PAGE_SIZE);currentOffset=data.offset;currentTotal=data.total;$('results').replaceChildren();data.results.forEach((gig,i)=>$('results').appendChild(renderGig(gig,i)));$('pagerWrap').classList.toggle('show',data.total>0);const from=data.total?data.offset+1:0,to=Math.min(data.offset+data.results.length,data.total);$('pagerInfo').textContent='Showing '+from+'–'+to+' of '+data.total;$('prev').disabled=data.offset<=0;$('next').disabled=!data.has_more}
$('prev').onclick=()=>loadResults(Math.max(0,currentOffset-PAGE_SIZE));$('next').onclick=()=>loadResults(currentOffset+PAGE_SIZE);
$('cancel').onclick=async()=>{if(!currentJobId)return;$('cancel').disabled=true;try{const job=await api('/api/jobs/'+currentJobId+'/cancel',{method:'POST'});renderJob(job)}catch(e){$('jobMessage').textContent=e.message}finally{$('cancel').disabled=false}};
$('form').addEventListener('submit',async e=>{e.preventDefault();$('submit').disabled=true;$('submit').textContent='Starting…';$('results').replaceChildren();$('summary').classList.remove('show');$('pagerWrap').classList.remove('show');$('analysisPanel').classList.remove('show');analysisData=null;try{const job=await api('/api/jobs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({niche:$('niche').value,limit:Number($('limit').value)})});currentJobId=job.id;localStorage.setItem('fiverr-current-job',currentJobId);renderJob(job);clearInterval(pollTimer);pollTimer=setInterval(pollJob,1500);await pollJob()}catch(e){$('jobPanel').classList.add('show');$('jobMessage').textContent=e.message;$('jobMessage').classList.add('error');$('submit').disabled=false;$('submit').textContent='Start background job'}});
async function openExistingJob(job){currentJobId=job.id;renderJob(job);if(['completed','cancelled'].includes(job.status)){showSummary(job);await loadAnalysis();await loadResults(0)}else if(['queued','running','cancelling'].includes(job.status)){localStorage.setItem('fiverr-current-job',currentJobId);$('submit').disabled=true;$('submit').textContent='Job running…';if(!pollTimer)pollTimer=setInterval(pollJob,1500)}}
(async()=>{const saved=localStorage.getItem('fiverr-current-job');if(saved){currentJobId=saved;$('submit').disabled=true;$('submit').textContent='Job running…';await pollJob();if($('submit').disabled&&!pollTimer)pollTimer=setInterval(pollJob,1500);return}try{const recent=await api('/api/jobs?limit=1');if(recent.jobs&&recent.jobs.length)await openExistingJob(recent.jobs[0])}catch{}})();
</script></body></html>"""
