import asyncio
import json
import unittest

import httpx

from openrouter_client import OpenRouterClient, OpenRouterConfig, estimate_cost


class OpenRouterClientTests(unittest.TestCase):
    def test_mocked_structured_chat_embeddings_and_key_status(self):
        requests = []

        def handler(request: httpx.Request) -> httpx.Response:
            requests.append(request)
            self.assertEqual(request.headers.get("authorization"), "Bearer sk-or-test-placeholder")
            if request.url.path.endswith("/key"):
                return httpx.Response(200, json={"data": {"label": "test", "limit": 1, "usage": 0.1}})
            if request.url.path.endswith("/embeddings"):
                body = json.loads(request.content)
                return httpx.Response(
                    200,
                    json={
                        "id": "emb-1",
                        "data": [
                            {"index": index, "embedding": [float(index + 1), 0.5]}
                            for index, _ in enumerate(body["input"])
                        ],
                        "usage": {"prompt_tokens": 10, "total_tokens": 10, "cost": 0.001},
                    },
                )
            body = json.loads(request.content)
            self.assertEqual(body["response_format"]["type"], "json_schema")
            self.assertTrue(body["provider"]["require_parameters"])
            return httpx.Response(
                200,
                json={
                    "id": "gen-1",
                    "choices": [{"message": {"content": '{"ok":true}'}}],
                    "usage": {
                        "prompt_tokens": 20,
                        "completion_tokens": 5,
                        "total_tokens": 25,
                        "cost": 0.002,
                    },
                },
            )

        async def run():
            transport = httpx.MockTransport(handler)
            async with httpx.AsyncClient(transport=transport) as http_client:
                config = OpenRouterConfig(
                    api_key="sk-or-test-placeholder",
                    base_url="https://openrouter.test/api/v1",
                    max_cost_usd=1,
                )
                client = OpenRouterClient(config, client=http_client)
                status = await client.key_status()
                self.assertTrue(status["valid"])
                vectors, emb_usage, _ = await client.embeddings(["one", "two"])
                self.assertEqual(len(vectors), 2)
                self.assertEqual(emb_usage.total_tokens, 10)
                data, usage, _ = await client.chat_json(
                    messages=[{"role": "user", "content": "test"}],
                    schema_name="test_schema",
                    schema={
                        "type": "object",
                        "properties": {"ok": {"type": "boolean"}},
                        "required": ["ok"],
                        "additionalProperties": False,
                    },
                    max_tokens=32,
                )
                self.assertTrue(data["ok"])
                self.assertEqual(usage.total_tokens, 25)
                public = config.public_dict()
                self.assertNotIn("api_key", public)
                self.assertNotIn("sk-or-test-placeholder", json.dumps(public))

        asyncio.run(run())
        self.assertEqual(len(requests), 3)

    def test_cost_estimator(self):
        self.assertAlmostEqual(
            estimate_cost("google/gemini-3.7-flash", 1_000_000, 1_000_000),
            2.25,
        )


if __name__ == "__main__":
    unittest.main()
