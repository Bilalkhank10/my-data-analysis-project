# Fiverr AI Market Intelligence — Phase 3

Local Fiverr public-market research system with three layers:

1. **Phase 1:** background crawl, ranks and SQLite snapshots
2. **Phase 2:** deterministic market analytics — no LLM
3. **Phase 3:** optional OpenRouter semantic audits with strict budgets and caching

## Security first

The API key is read only from `OPENROUTER_API_KEY` at process startup. It is never:

- returned by an API endpoint
- stored in SQLite
- written to JSON/CSV exports
- printed in application logs
- embedded in frontend JavaScript
- committed to source control

If a key was pasted into chat, revoke it and create a new limited-credit key before use.

## Phase 3 models

Defaults:

```text
Primary:   google/gemini-3.7-flash
Embedding: google/gemini-embedding-001
Deep:      anthropic/claude-sonnet-5
```

All model IDs are configurable through environment variables.

## Phase 3 modes

### Dry run — default

- no OpenRouter request
- no tokens
- no cost
- selects representative gigs
- estimates input/output tokens and projected cost
- shows the exact model plan

### Tiny live test

- one representative gig
- one embedding batch
- one constrained structured audit
- one constrained synthesis
- intended only after a rotated key is securely configured

### Standard audit

- bulk gig audits with the economical primary model
- embeddings and similarity
- primary-model market synthesis

### Deep audit

- same bulk flow
- premium deep model only for final market synthesis

## Semantic outputs

- buyer intent and problem
- desired outcome and deliverables
- target buyer, industry, tools and project type
- Neo-readiness diagnostic
- intent clarity
- conversion readiness
- trust/proof score
- package consistency
- semantic differentiation
- high-ticket readiness
- compliance-risk diagnostic
- positioning archetype
- strengths, weaknesses and recommendations
- evidence ledger with source quote/reason/confidence
- nearest semantic competitors
- most-similar gig pairs
- market positioning synthesis
- semantic market gaps
- high-ticket opportunities
- optional own-gig audit

These are public-data diagnostics, not Fiverr Neo output, private feedback, CTR/CR, Success Score internals or secret ranking weights.

## Cost controls

- hard per-run USD cap
- representative-gig sampling instead of sending 500 raw pages
- compact public inputs
- strict output-token limits
- SQLite prompt/result cache
- SQLite embedding cache
- OpenRouter response-cache header
- per-run prompt, completion, total token and actual-cost accounting
- no automatic AI run after crawling; user must click **Run Phase 3**

## Structured outputs

OpenRouter requests use:

```json
{
  "provider": {"require_parameters": true},
  "response_format": {
    "type": "json_schema",
    "json_schema": {
      "strict": true
    }
  }
}
```

Scraped page text is explicitly treated as untrusted input. Models are instructed not to execute/follow instructions contained inside gig descriptions or reviews.

## Installation

Python 3.11+ recommended.

### Windows

```bat
cd fiverr-niche-fetcher
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
set OPENROUTER_API_KEY=YOUR_NEW_ROTATED_KEY
run.bat
```

### macOS/Linux

```bash
cd fiverr-niche-fetcher
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENROUTER_API_KEY="YOUR_NEW_ROTATED_KEY"
./run.sh
```

Open `http://127.0.0.1:8000`.

Without a key, Phase 1, Phase 2 and Phase 3 dry-run mode still work completely.

## Recommended environment configuration

```env
OPENROUTER_API_KEY=
OPENROUTER_MODEL=google/gemini-3.7-flash
OPENROUTER_EMBEDDING_MODEL=google/gemini-embedding-001
OPENROUTER_DEEP_MODEL=anthropic/claude-sonnet-5
OPENROUTER_MAX_COST_USD=2.00
OPENROUTER_MAX_GIGS=25
OPENROUTER_MAX_OUTPUT_TOKENS=2500
OPENROUTER_TIMEOUT_SECONDS=120
```

Start with a newly created key carrying a very small spending limit.

## API

### Public AI configuration — never returns the key

```http
GET /api/ai/config
```

### Validate configured key — no inference tokens

```http
POST /api/ai/validate-key
```

### Start Phase 3 run

```http
POST /api/jobs/{job_id}/ai-runs
Content-Type: application/json

{
  "mode": "dry_run",
  "max_gigs": 10,
  "own_gig_url": null
}
```

Modes: `dry_run`, `test`, `standard`, `deep`.

### AI run status

```http
GET /api/ai-runs/{run_id}
```

### AI result

```http
GET /api/ai-runs/{run_id}/result
```

### Previous runs

```http
GET /api/jobs/{job_id}/ai-runs
```

## SQLite tables

Phase 3 adds:

- `ai_runs` — status, model, tokens, cost, result
- `ai_cache` — prompt-hash structured response cache
- `embedding_cache` — model/input-hash vector cache

Existing Phase 1/2 tables remain unchanged.

## UI

Phase 3 adds:

- OpenRouter configuration state
- dry/test/standard/deep selector
- max-gig selector
- optional own-gig URL
- AI run progress, token and cost display
- AI Overview
- Intent Map
- Scores
- Similarity
- Market Synthesis
- Evidence
- Usage & Cost

## Tests

```bash
python -m unittest discover -s tests -v
```

The test suite uses mocked OpenRouter HTTP responses. It validates structured JSON, embeddings, usage accounting, caching and full Phase 3 orchestration without consuming real tokens.

## Operational boundaries

- Public URLs are sent to Jina Reader during crawling.
- Selected compressed public text is sent to OpenRouter only when a real AI mode is explicitly started.
- Dry run sends nothing to OpenRouter.
- Review usernames are not needed in prompts.
- No login, CAPTCHA or access-control bypass is used.
- Always comply with Fiverr/OpenRouter terms and applicable law.
