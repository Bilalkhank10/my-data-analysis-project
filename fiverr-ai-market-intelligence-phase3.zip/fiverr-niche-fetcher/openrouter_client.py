"""Minimal OpenRouter client with strict JSON, embeddings and cost accounting.

Secrets are read only from OPENROUTER_API_KEY. They are never returned by any
method, persisted, logged, or included in exception messages.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

import httpx

OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"
MODEL_PRICES_PER_MILLION: dict[str, tuple[float, float]] = {
    "google/gemini-3.7-flash": (0.375, 1.875),
    "google/gemini-3.7-flash:batch": (0.1875, 0.9375),
    "google/gemini-embedding-001": (0.15, 0.0),
    "anthropic/claude-sonnet-5": (2.0, 10.0),
    "anthropic/claude-sonnet-5:batch": (1.0, 5.0),
}


class OpenRouterError(RuntimeError):
    pass


class BudgetExceeded(OpenRouterError):
    pass


@dataclass(repr=False)
class OpenRouterConfig:
    api_key: str
    base_url: str = OPENROUTER_BASE_URL
    primary_model: str = "google/gemini-3.7-flash"
    embedding_model: str = "google/gemini-embedding-001"
    deep_model: str = "anthropic/claude-sonnet-5"
    max_cost_usd: float = 2.0
    max_gigs: int = 25
    max_output_tokens: int = 2500
    request_timeout_seconds: float = 120.0
    app_title: str = "Fiverr Market Intelligence"
    app_url: str = "http://localhost:8000"

    @property
    def configured(self) -> bool:
        return bool(self.api_key and self.api_key.startswith("sk-or-"))

    @classmethod
    def from_env(cls) -> "OpenRouterConfig":
        return cls(
            api_key=os.getenv("OPENROUTER_API_KEY", "").strip(),
            base_url=os.getenv("OPENROUTER_BASE_URL", OPENROUTER_BASE_URL).rstrip("/"),
            primary_model=os.getenv("OPENROUTER_MODEL", "google/gemini-3.7-flash"),
            embedding_model=os.getenv(
                "OPENROUTER_EMBEDDING_MODEL", "google/gemini-embedding-001"
            ),
            deep_model=os.getenv("OPENROUTER_DEEP_MODEL", "anthropic/claude-sonnet-5"),
            max_cost_usd=max(0.01, float(os.getenv("OPENROUTER_MAX_COST_USD", "2.0"))),
            max_gigs=max(1, min(50, int(os.getenv("OPENROUTER_MAX_GIGS", "25")))),
            max_output_tokens=max(
                128, min(8000, int(os.getenv("OPENROUTER_MAX_OUTPUT_TOKENS", "2500")))
            ),
            request_timeout_seconds=max(
                15.0, min(300.0, float(os.getenv("OPENROUTER_TIMEOUT_SECONDS", "120")))
            ),
            app_title=os.getenv("OPENROUTER_APP_TITLE", "Fiverr Market Intelligence"),
            app_url=os.getenv("OPENROUTER_APP_URL", "http://localhost:8000"),
        )

    def public_dict(self) -> dict[str, Any]:
        return {
            "configured": self.configured,
            "base_url": self.base_url,
            "primary_model": self.primary_model,
            "embedding_model": self.embedding_model,
            "deep_model": self.deep_model,
            "max_cost_usd": self.max_cost_usd,
            "max_gigs": self.max_gigs,
            "max_output_tokens": self.max_output_tokens,
        }


@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0
    cached_tokens: int = 0

    @classmethod
    def from_response(cls, response: dict[str, Any]) -> "Usage":
        usage = response.get("usage") or {}
        prompt_details = usage.get("prompt_tokens_details") or {}
        return cls(
            prompt_tokens=int(usage.get("prompt_tokens") or 0),
            completion_tokens=int(usage.get("completion_tokens") or 0),
            total_tokens=int(usage.get("total_tokens") or 0),
            cost=float(usage.get("cost") or 0.0),
            cached_tokens=int(prompt_details.get("cached_tokens") or 0),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "cost": self.cost,
            "cached_tokens": self.cached_tokens,
        }


def estimate_tokens(text: str) -> int:
    # Conservative language-agnostic approximation for preflight budgeting.
    return max(1, (len(text) + 2) // 3)


def estimate_cost(
    model: str, input_tokens: int, output_tokens: int = 0
) -> float:
    input_price, output_price = MODEL_PRICES_PER_MILLION.get(model, (2.0, 10.0))
    return (input_tokens / 1_000_000) * input_price + (
        output_tokens / 1_000_000
    ) * output_price


class OpenRouterClient:
    def __init__(
        self,
        config: OpenRouterConfig | None = None,
        *,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.config = config or OpenRouterConfig.from_env()
        self._client = client

    def _headers(self) -> dict[str, str]:
        if not self.config.configured:
            raise OpenRouterError(
                "OPENROUTER_API_KEY is not configured. Set a new rotated key in the environment."
            )
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": self.config.app_url,
            "X-OpenRouter-Title": self.config.app_title,
            "X-OpenRouter-Cache": "true",
        }

    async def _request(
        self, method: str, path: str, *, payload: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        own_client = self._client is None
        client = self._client or httpx.AsyncClient(
            timeout=self.config.request_timeout_seconds, follow_redirects=True
        )
        try:
            response = await client.request(
                method,
                f"{self.config.base_url}{path}",
                headers=self._headers(),
                json=payload,
            )
            if response.status_code >= 400:
                # Do not include request headers or raw bodies in errors.
                message = "OpenRouter request failed"
                try:
                    body = response.json()
                    public_error = body.get("error") or {}
                    if isinstance(public_error, dict) and public_error.get("message"):
                        message = str(public_error["message"])
                except Exception:
                    pass
                raise OpenRouterError(f"{message} (HTTP {response.status_code})")
            return response.json()
        except httpx.HTTPError as exc:
            raise OpenRouterError(f"OpenRouter network error: {type(exc).__name__}") from exc
        finally:
            if own_client:
                await client.aclose()

    async def key_status(self) -> dict[str, Any]:
        response = await self._request("GET", "/key")
        data = response.get("data") or response
        # Return only non-secret operational fields.
        return {
            "valid": True,
            "label": data.get("label"),
            "limit": data.get("limit"),
            "limit_remaining": data.get("limit_remaining"),
            "usage": data.get("usage"),
            "is_free_tier": data.get("is_free_tier"),
        }

    async def chat_json(
        self,
        *,
        messages: list[dict[str, str]],
        schema_name: str,
        schema: dict[str, Any],
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float = 0.0,
    ) -> tuple[dict[str, Any], Usage, str]:
        selected_model = model or self.config.primary_model
        max_tokens = max_tokens or self.config.max_output_tokens
        prompt_text = json.dumps(messages, ensure_ascii=False)
        preflight = estimate_cost(
            selected_model, estimate_tokens(prompt_text), max_tokens
        )
        if preflight > self.config.max_cost_usd:
            raise BudgetExceeded(
                f"Single request estimate ${preflight:.4f} exceeds configured run cap."
            )
        payload = {
            "model": selected_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "provider": {"require_parameters": True},
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": schema_name,
                    "strict": True,
                    "schema": schema,
                },
            },
        }
        response = await self._request("POST", "/chat/completions", payload=payload)
        choices = response.get("choices") or []
        if not choices:
            raise OpenRouterError("OpenRouter returned no completion choices.")
        content = (choices[0].get("message") or {}).get("content")
        if isinstance(content, dict):
            parsed = content
        else:
            try:
                parsed = json.loads(str(content))
            except json.JSONDecodeError as exc:
                raise OpenRouterError("Model returned invalid JSON despite structured mode.") from exc
        return parsed, Usage.from_response(response), str(response.get("id") or "")

    async def embeddings(
        self,
        inputs: list[str],
        *,
        model: str | None = None,
    ) -> tuple[list[list[float]], Usage, str]:
        selected_model = model or self.config.embedding_model
        input_tokens = sum(estimate_tokens(value) for value in inputs)
        preflight = estimate_cost(selected_model, input_tokens, 0)
        if preflight > self.config.max_cost_usd:
            raise BudgetExceeded(
                f"Embedding estimate ${preflight:.4f} exceeds configured run cap."
            )
        response = await self._request(
            "POST",
            "/embeddings",
            payload={"model": selected_model, "input": inputs},
        )
        data = sorted(response.get("data") or [], key=lambda item: item.get("index", 0))
        vectors = [item.get("embedding") or [] for item in data]
        if len(vectors) != len(inputs):
            raise OpenRouterError("Embedding response count did not match input count.")
        return vectors, Usage.from_response(response), str(response.get("id") or "")
